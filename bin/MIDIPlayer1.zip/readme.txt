Program: MIDIPlayer
Version: 1.0
Operating System:  Windows
Release Date: 12/17/2005
Author:  Xangis
License:  Totally free
Download Location:  www.xangis.com
Installation:  Unzip anywhere convenient.
Use:  Run the program.  Browse for a MIDI file to play and click
      the "Play" button.  Stop the playback by hitting the "Stop"
      button.  You can also type a filename in the "File:" box.
      Filenames without a path will be looked for in the same
      directory as the executable file.

      Requires DirectX 8 or higher.